#pragma once
constexpr int MAX_ID_LEN = 50;
constexpr int MAX_STR_LEN = 255;

#define WORLD_WIDTH		400
#define WORLD_HEIGHT	400

#define NPC_ID_START	20000

#define SERVER_PORT		9000
#define NUM_NPC			100
